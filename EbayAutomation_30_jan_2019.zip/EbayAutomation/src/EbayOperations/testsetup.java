package EbayOperations;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;

public class testsetup {
	
	public static AndroidDriver<AndroidElement> setup() throws MalformedURLException {
		
		//Using file class to provide the info on the application path
		File fsource = new File("src");
		File fpath = new File(fsource,"eBay.apk");
		
		//Defining the desired capabilities regarding the emulator info and the application under test
		DesiredCapabilities capability = new DesiredCapabilities();
		capability.setCapability(MobileCapabilityType.DEVICE_NAME, "3abace39");
		capability.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		capability.setCapability(MobileCapabilityType.PLATFORM_VERSION, "6.0.1");
		capability.setCapability(MobileCapabilityType.APPLICATION_NAME, "com.ebay.mobile");
		capability.setCapability(MobileCapabilityType.APP, fpath.getAbsolutePath());
		
		//Defining AndroidDriver class as the test execution is on Android OS
		AndroidDriver<AndroidElement> driver =  new AndroidDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), capability);
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		return driver;
	}
		
}
