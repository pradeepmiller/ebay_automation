package EbayOperations;

import java.io.FileInputStream;
import java.net.MalformedURLException;

import EbayPages.signinpage;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class ebaysignin extends testsetup{

	public static AndroidDriver<AndroidElement> ebaySignin() throws MalformedURLException {
		
		AndroidDriver<AndroidElement> driver = setup();
		if(driver.findElement(signinpage.signin_title).isDisplayed())
			System.out.println("Pass: Sign-in page title is displayed successfully");
		if(driver.findElement(signinpage.close_button).isDisplayed())
			System.out.println("Pass: Close button on sign-in page is displayed successfully");		
	
		
		driver.findElement(signinpage.email_username_field).sendKeys();
		driver.findElement(signinpage.password_field).sendKeys();
		if(driver.findElement(signinpage.password_field).getText().compareTo(anotherString))
			System.out.println("Fail: Password is not decrypted");
		if(driver.findElement(signinpage.show_password_option).isDisplayed())
			System.out.println("Pass: Password is shown as encrypted with show option successfully");	
		driver.findElement(signinpage.show_password_option).click();
		if(driver.findElement(signinpage.hide_password_option).isDisplayed())
			System.out.println("Pass: Password is shown as decrypted with hide option");	
		if(driver.findElement(signinpage.forgot_button).isDisplayed())
			System.out.println("Pass: Forgot password option is shown succcessfully");	
		driver.findElement(signinpage.forgot_button).click();
		if(driver.findElement().isDisplayed())
			System.out.println("Pass: Naviagted to Forgot password screen succcessfully");	
		driver.findElement().click();		
		
		
		return driver;
		
	}
	
}

