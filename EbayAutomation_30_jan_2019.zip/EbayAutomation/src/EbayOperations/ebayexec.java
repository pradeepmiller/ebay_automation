package EbayOperations;

import java.net.MalformedURLException;

public class ebayexec {
	
	public static void main(String args[]) throws MalformedURLException {
			
		ebaysignin.ebaySignin();
		
	}
	

}
