package EbayOperations;

import java.net.MalformedURLException;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class ebaysearch {

	public static AndroidDriver<AndroidElement> search() throws MalformedURLException {
		
		
		return driver;
		
		
		
	}
}
